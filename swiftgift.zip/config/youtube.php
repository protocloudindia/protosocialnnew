<?php


// You can find the keys here : https://console.developers.google.com

return [
    'KEY' => 'AIzaSyB4xSPAHW4XU6QgcKhuRq2y522B15FHdpc',
];
